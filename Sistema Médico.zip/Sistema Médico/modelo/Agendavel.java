package modelo;

public interface Agendavel {

    void agendar();
    void cancelar();
}